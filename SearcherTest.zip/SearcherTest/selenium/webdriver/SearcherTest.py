from selenium import webdriver
from selenium.webdriver.common.keys import Keys
import time

# New Stuff
# dir = os.path.dirname(__file__)
# chrome_path = os.path.join(dir, selenium','webdriver','chromedriver.exe')
# service = service.Service(chrome_path)
# New Stuff

#Question
srch = input("What are you searching for?")

browser=webdriver.Chrome()

#first tab
browser.get('https://www.ncbi.nlm.nih.gov/pubmed/')
element = browser.find_element_by_name('term')
element.send_keys(srch)
element.send_keys(Keys.RETURN)

#second tab
browser.execute_script("window.open('about:blank', 'tab2');")
browser.switch_to.window("tab2")
browser.get('https://scholar.google.com/')
element = browser.find_element_by_name('q')
element.send_keys(srch)
element.send_keys(Keys.RETURN)

#third tab
browser.execute_script("window.open('about:blank', 'tab3');")
browser.switch_to.window("tab3")
browser.get('https://google.com')
element = browser.find_element_by_name('q')
element.send_keys(srch)
element.send_keys(Keys.RETURN)

#fourth tab
browser.execute_script("window.open('about:blank', 'tab4');")
browser.switch_to.window("tab4")
browser.get('https://www.plos.org/')
time.sleep(5)
element = browser.find_element_by_name('q')
element.send_keys(srch)
element.send_keys(Keys.RETURN)