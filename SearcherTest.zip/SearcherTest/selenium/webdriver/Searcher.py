from selenium import webdriver
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.common.action_chains import ActionChains
import time
import os

driver = webdriver.ChromeOptions()    
driver.add_argument('--headless')

srch = input("What are you searching for?")

driver = webdriver.Chrome()
# 1
driver.get('https://www.ncbi.nlm.nih.gov/pubmed/')
element = driver.find_element_by_name('term')
# element.send_keys(srch)
# element.send_keys(Keys.RETURN)
element.send_keys(Keys.CONTROL + 't')
time.sleep(3)
# 2
driver.get('https://scholar.google.com/')
element = driver.find_element_by_name('q')
# element.send_keys(srch)
# element.send_keys(Keys.RETURN)
